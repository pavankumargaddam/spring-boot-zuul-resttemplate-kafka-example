package org.test1.config;

import org.springframework.cloud.stream.annotation.EnableBinding;


//Enabling the channels which are configured in ChannelConfig class
@EnableBinding(value = ChannelConfig.class)
public class MessagingConfiguration {
}
