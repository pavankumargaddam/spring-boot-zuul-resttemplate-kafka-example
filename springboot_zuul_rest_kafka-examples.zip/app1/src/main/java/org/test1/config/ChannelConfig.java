package org.test1.config;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface ChannelConfig {

    String TEST_INPUT = "test-input";

    //String TEST_OUTPUT = "test-output";

    @Input(TEST_INPUT)
    SubscribableChannel testInput();

//    @Output(TEST_OUTPUT)
//    SubscribableChannel testOutput();

}


