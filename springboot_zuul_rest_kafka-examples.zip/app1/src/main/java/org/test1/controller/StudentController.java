package org.test1.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.test1.domain.Student;

import java.util.Arrays;
import java.util.List;

@RequestMapping("/api")
@RestController
public class StudentController {


    @GetMapping("/studentlist")
    public List<Student> studentList() {
        List<Student> studentList = Arrays.asList(
                new Student(10L, "pavan", "kumar"),
                new Student(9L, "sasi", "dhar"),
                new Student(25L, "bharath", "reddy")
        );
        System.out.println(studentList);
        return studentList;
    }

    @GetMapping("/student")
    public Student getStudent() {
        Student student = new Student(10L, "pavan", "kumar");
        System.out.println(student);
        return student;
    }

    @PostMapping("/create")
    public ResponseEntity<Student> create(@RequestBody Student student){
        Student student1 = new Student();
        student1.setId(student.getId()+200L);
        student1.setfName(student.getfName()+"dummy");
        student1.setlName(student.getlName()+"dumm1");
        return new ResponseEntity<>(student1, HttpStatus.CREATED);
    }

}
