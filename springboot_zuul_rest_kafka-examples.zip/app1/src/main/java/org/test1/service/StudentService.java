package org.test1.service;


import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Service;
import org.test1.domain.Student;

import static org.test1.config.ChannelConfig.TEST_INPUT;

@Service
public class StudentService {

    //Kafka Consumer Channel for topic test
    @ServiceActivator(inputChannel = TEST_INPUT)
    public void consumeMessage(Student student){
        System.out.println(student);
    }
}
