package org.test2.channel;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.SubscribableChannel;

/**
 * Channels entries
 */
public interface ChannelConfiguration {

   // String TEST_INPUT = "test-input";

    String TEST_OUTPUT = "test-output";

  /*  @Input(TEST_INPUT)
    SubscribableChannel testInput();*/

    @Output(TEST_OUTPUT)
    SubscribableChannel testOutput();
}
