package org.test2.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.*;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.test2.domain.Student;

import static org.test2.channel.ChannelConfiguration.TEST_OUTPUT;

@RequestMapping("/app2")
@RestController
public class StudentController {

    private static String BASE_URL = "http://localhost:2500/";


    @Autowired
    @Qualifier(TEST_OUTPUT)
    private MessageChannel testChannel;

    @GetMapping("/fetch")
    public Student getStudentUsingEntity() {
        RestTemplate restTemplate = new RestTemplate();
        //rest template call
        ResponseEntity<Student> templateForEntity = restTemplate.getForEntity(BASE_URL + "api/student", Student.class);
        System.out.println("Student : " + templateForEntity.getBody());
        return templateForEntity.getBody();
    }

    @GetMapping("/fetchusingexchange")
    public Student getStudentUsingExchange() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> httpEntity = new HttpEntity<>(httpHeaders);
        RestTemplate restTemplate = new RestTemplate();
        //rest template call
        ResponseEntity<Student> studentResponseEntity = restTemplate.exchange(BASE_URL + "api/student", HttpMethod.GET, httpEntity, Student.class);
        System.out.println("Student : " + studentResponseEntity.getBody());
        return studentResponseEntity.getBody();
    }


    @GetMapping("/student")
    public ResponseEntity<Student> createStudent() {
        Student student = new Student();
        student.setfName("lava");
        student.setlName("kumar");
        student.setId(100L);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.add("cookie","dummyvalue");
        HttpEntity<Student> httpEntity = new HttpEntity<>(student, httpHeaders);
        RestTemplate restTemplate = new RestTemplate();
        //restTemplate call
        ResponseEntity<Student> studentResponseEntity = restTemplate.exchange(BASE_URL + "api/create", HttpMethod.POST, httpEntity, Student.class);
        restTemplate.postForObject(BASE_URL + "api/create", student, Student.class);
        System.out.println("Student : " + studentResponseEntity.getBody());
        return studentResponseEntity;
    }

    //Kafka Producer
    @GetMapping("/kafka/producer")
    public void sendData(){
        Student student = new Student();
        student.setId(1000L);
        student.setfName("Kafka First");
        student.setlName("Kafka Last");

        //sending data using kafka (publisher)
        testChannel.send(MessageBuilder.withPayload(student).build());
    }

}
