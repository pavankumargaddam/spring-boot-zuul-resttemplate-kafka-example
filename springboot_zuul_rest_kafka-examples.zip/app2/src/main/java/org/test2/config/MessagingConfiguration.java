package org.test2.config;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.test2.channel.ChannelConfiguration;

//Enabling the channels which are configured in ChannelConfiguration class
@EnableBinding(value = ChannelConfiguration.class)
public class MessagingConfiguration {
}
